from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.dependencies import get_db, require_api_auth
from app.models.beat import Beat
from app.models.company import SystemConfiguration
from app.models.geography import Geography
from app.models.outlet import Outlet, OutletStatus
from app.models.product import Product
from app.models.user import User

router = APIRouter(prefix="/api/v1", tags=["mobile-master"])


@router.get("/geography/tree")
async def geography_tree(
    current_user: User = Depends(require_api_auth),
    db: Session = Depends(get_db),
):
    """Full active geography tree for mobile offline cache."""
    def _node(geo: Geography) -> dict:
        return {
            "id": geo.id,
            "name": geo.name,
            "code": geo.code,
            "level": geo.level.value,
            "erp_id": geo.erp_id,
            "children": [_node(c) for c in geo.children if c.is_active],
        }

    roots = (
        db.query(Geography)
        .filter(Geography.parent_id == None, Geography.is_active == True)
        .order_by(Geography.name)
        .all()
    )
    return {"tree": [_node(g) for g in roots]}


@router.get("/beats/daily-plan")
async def beat_daily_plan(
    beat_id: int = Query(...),
    current_user: User = Depends(require_api_auth),
    db: Session = Depends(get_db),
):
    """Ordered outlet list for a beat (approved outlets only)."""
    beat = db.query(Beat).filter(Beat.id == beat_id, Beat.is_active == True).first()
    if not beat:
        return {"beat": None, "outlets": []}

    outlets = (
        db.query(Outlet)
        .filter(Outlet.beat_id == beat_id, Outlet.status == OutletStatus.active)
        .order_by(Outlet.name)
        .all()
    )
    return {
        "beat": {
            "id": beat.id,
            "name": beat.name,
            "code": beat.code,
            "beat_type": beat.beat_type.value,
        },
        "outlets": [
            {
                "id": o.id,
                "name": o.name,
                "code": o.code,
                "owner_name": o.owner_name,
                "mobile": o.mobile,
                "address": o.address,
                "channel": o.channel,
                "gps_lat": o.gps_lat,
                "gps_lng": o.gps_lng,
            }
            for o in outlets
        ],
    }


@router.get("/outlets")
async def outlet_list(
    beat_id: Optional[int] = Query(default=None),
    page: int = Query(default=1, ge=1),
    per_page: int = Query(default=50, ge=1, le=200),
    current_user: User = Depends(require_api_auth),
    db: Session = Depends(get_db),
):
    """Paginated approved outlets, optionally filtered by beat."""
    query = db.query(Outlet).filter(Outlet.status == OutletStatus.active)
    if beat_id:
        query = query.filter(Outlet.beat_id == beat_id)
    query = query.order_by(Outlet.name)
    total = query.count()
    items = query.offset((page - 1) * per_page).limit(per_page).all()
    return {
        "total": total,
        "page": page,
        "per_page": per_page,
        "items": [
            {
                "id": o.id,
                "name": o.name,
                "code": o.code,
                "beat_id": o.beat_id,
                "territory_id": o.territory_id,
                "owner_name": o.owner_name,
                "mobile": o.mobile,
                "address": o.address,
                "channel": o.channel,
                "gps_lat": o.gps_lat,
                "gps_lng": o.gps_lng,
            }
            for o in items
        ],
    }


@router.get("/products")
async def product_list(
    current_user: User = Depends(require_api_auth),
    db: Session = Depends(get_db),
):
    """All active products for mobile offline cache."""
    products = db.query(Product).filter(Product.is_active == True).order_by(Product.name).all()
    return {
        "items": [
            {
                "id": p.id,
                "name": p.name,
                "erp_id": p.erp_id,
                "sku": p.sku,
                "division": p.division,
                "primary_category": p.primary_category,
                "secondary_category": p.secondary_category,
                "mrp": float(p.mrp) if p.mrp else None,
                "gst_rate": float(p.gst_rate) if p.gst_rate else 0,
                "must_sell": p.must_sell,
            }
            for p in products
        ]
    }


@router.get("/config")
async def system_config(
    current_user: User = Depends(require_api_auth),
    db: Session = Depends(get_db),
):
    """SystemConfiguration for mobile (payment mode, GPS threshold, sync interval)."""
    config = db.query(SystemConfiguration).filter(SystemConfiguration.id == 1).first()
    if not config:
        return {
            "payment_mode": "cash_and_online",
            "denomination_mandatory": False,
            "gps_threshold_metres": 100,
            "sync_interval_seconds": 300,
        }
    return {
        "payment_mode": config.payment_mode.value,
        "denomination_mandatory": config.denomination_mandatory,
        "gps_threshold_metres": config.gps_threshold_metres,
        "sync_interval_seconds": config.sync_interval_seconds,
    }
