from typing import Optional

from fastapi import APIRouter, Depends, Form, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.dependencies import get_db, require_web_auth, require_web_roles
from app.models.beat import Beat
from app.models.position import Position, PositionLevel
from app.models.user import User, UserRole
from app.utils.flash import get_flash, set_flash_error, set_flash_success
from app.utils.pagination import paginate

router = APIRouter(prefix="/positions", tags=["positions"])
templates = Jinja2Templates(directory="app/templates")


def validate_position_hierarchy(db: Session, level_str: str, reporting_to_id: Optional[str], current_pos_id: Optional[int] = None) -> Optional[str]:
    try:
        level = PositionLevel(level_str)
    except ValueError:
        return f"Invalid position level: {level_str}"
        
    if level == PositionLevel.L4:
        if reporting_to_id and reporting_to_id.strip() != "":
            return "L4 positions cannot report to any parent position."
    else:
        if not reporting_to_id or reporting_to_id.strip() == "":
            return f"Reports To is mandatory for {level.value} level position."
        
        try:
            rid = int(reporting_to_id)
        except ValueError:
            return "Invalid parent position selected."

        if current_pos_id and rid == current_pos_id:
            return "A position cannot report to itself."
            
        parent = db.query(Position).filter(Position.id == rid).first()
        if not parent:
            return "Parent position not found."
        if not parent.is_active:
            return f"Cannot report to inactive position '{parent.name}'."
            
        if level == PositionLevel.L3 and parent.level != PositionLevel.L4:
            return f"An L3 position must report to an L4 position (selected reports to level: {parent.level.value})."
        elif level == PositionLevel.L2 and parent.level != PositionLevel.L3:
            return f"An L2 position must report to an L3 position (selected reports to level: {parent.level.value})."
        elif level == PositionLevel.L1 and parent.level != PositionLevel.L2:
            return f"An L1 position must report to an L2 position (selected reports to level: {parent.level.value})."
            
    return None


@router.get("", response_class=HTMLResponse)
async def position_list(
    request: Request,
    current_user: User = Depends(require_web_auth),
    db: Session = Depends(get_db),
    q: str = Query(default=""),
    level: str = Query(default=""),
    page: int = Query(default=1, ge=1),
):
    query = db.query(Position)
    if q:
        query = query.filter(Position.name.ilike(f"%{q}%") | Position.code.ilike(f"%{q}%"))
    if level and level in [lv.value for lv in PositionLevel]:
        query = query.filter(Position.level == level)
    query = query.order_by(Position.level, Position.name)
    pagination = paginate(query, page)
    return templates.TemplateResponse("positions/list.html", {
        "request": request, "current_user": current_user,
        "pagination": pagination, "q": q, "level": level,
        "PositionLevel": PositionLevel, **get_flash(request),
    })


@router.get("/new", response_class=HTMLResponse)
async def position_new(
    request: Request,
    current_user: User = Depends(require_web_roles(UserRole.admin)),
    db: Session = Depends(get_db),
):
    managers = db.query(Position).filter(Position.is_active == True).order_by(Position.name).all()
    beats = db.query(Beat).filter(Beat.is_active == True).order_by(Beat.name).all()
    users = db.query(User).filter(User.is_active == True).order_by(User.full_name).all()
    return templates.TemplateResponse("positions/form.html", {
        "request": request, "current_user": current_user,
        "item": None, "managers": managers, "beats": beats, "users": users, "PositionLevel": PositionLevel, "error": None,
    })


@router.post("/new")
async def position_create(
    request: Request,
    current_user: User = Depends(require_web_roles(UserRole.admin)),
    db: Session = Depends(get_db),
    name: str = Form(...),
    code: str = Form(...),
    level: str = Form(...),
    reporting_to_id: Optional[str] = Form(default=None),
    beat_ids: list[str] = Form(default=[]),
    attached_user_id: Optional[str] = Form(default=None),
):
    if db.query(Position).filter(Position.code == code.upper()).first():
        managers = db.query(Position).filter(Position.is_active == True).order_by(Position.name).all()
        beats = db.query(Beat).filter(Beat.is_active == True).order_by(Beat.name).all()
        users = db.query(User).filter(User.is_active == True).order_by(User.full_name).all()
        return templates.TemplateResponse("positions/form.html", {
            "request": request, "current_user": current_user,
            "item": None, "managers": managers, "beats": beats, "users": users, "PositionLevel": PositionLevel,
            "error": f"Code '{code.upper()}' already exists.",
        })
        
    err = validate_position_hierarchy(db, level, reporting_to_id)
    if err:
        managers = db.query(Position).filter(Position.is_active == True).order_by(Position.name).all()
        beats = db.query(Beat).filter(Beat.is_active == True).order_by(Beat.name).all()
        users = db.query(User).filter(User.is_active == True).order_by(User.full_name).all()
        return templates.TemplateResponse("positions/form.html", {
            "request": request, "current_user": current_user,
            "item": None, "managers": managers, "beats": beats, "users": users, "PositionLevel": PositionLevel,
            "error": err,
        })

    rid = int(reporting_to_id) if (reporting_to_id and reporting_to_id.strip() != "") else None
    
    pos = Position(name=name, code=code.upper(), level=PositionLevel(level), reporting_to_id=rid)
    if beat_ids:
        beat_objs = db.query(Beat).filter(Beat.id.in_(beat_ids)).all()
        pos.beats.extend(beat_objs)
    if attached_user_id and attached_user_id.strip() != "":
        user_obj = db.query(User).filter(User.id == int(attached_user_id)).first()
        if user_obj:
            pos.users.append(user_obj)
    db.add(pos)
    db.commit()
    set_flash_success(request, f"Position '{name}' created.")
    return RedirectResponse("/positions", status_code=302)


@router.get("/{pos_id}/edit", response_class=HTMLResponse)
async def position_edit(
    pos_id: int, request: Request,
    current_user: User = Depends(require_web_roles(UserRole.admin)),
    db: Session = Depends(get_db),
):
    item = db.query(Position).filter(Position.id == pos_id).first()
    if not item:
        set_flash_error(request, "Position not found.")
        return RedirectResponse("/positions", status_code=302)
    managers = db.query(Position).filter(Position.is_active == True, Position.id != pos_id).order_by(Position.name).all()
    beats = db.query(Beat).filter(Beat.is_active == True).order_by(Beat.name).all()
    users = db.query(User).filter(User.is_active == True).order_by(User.full_name).all()
    return templates.TemplateResponse("positions/form.html", {
        "request": request, "current_user": current_user,
        "item": item, "managers": managers, "beats": beats, "users": users, "PositionLevel": PositionLevel, "error": None,
    })


@router.post("/{pos_id}/edit")
async def position_update(
    pos_id: int, request: Request,
    current_user: User = Depends(require_web_roles(UserRole.admin)),
    db: Session = Depends(get_db),
    name: str = Form(...),
    code: str = Form(...),
    level: str = Form(...),
    reporting_to_id: Optional[str] = Form(default=None),
    is_active: Optional[str] = Form(default=None),
    beat_ids: list[str] = Form(default=[]),
    attached_user_id: Optional[str] = Form(default=None),
):
    item = db.query(Position).filter(Position.id == pos_id).first()
    if not item:
        set_flash_error(request, "Position not found.")
        return RedirectResponse("/positions", status_code=302)
    if db.query(Position).filter(Position.code == code.upper(), Position.id != pos_id).first():
        managers = db.query(Position).filter(Position.is_active == True, Position.id != pos_id).order_by(Position.name).all()
        beats = db.query(Beat).filter(Beat.is_active == True).order_by(Beat.name).all()
        users = db.query(User).filter(User.is_active == True).order_by(User.full_name).all()
        return templates.TemplateResponse("positions/form.html", {
            "request": request, "current_user": current_user,
            "item": item, "managers": managers, "beats": beats, "users": users, "PositionLevel": PositionLevel,
            "error": f"Code '{code.upper()}' already in use.",
        })
        
    err = validate_position_hierarchy(db, level, reporting_to_id, current_pos_id=pos_id)
    if err:
        managers = db.query(Position).filter(Position.is_active == True, Position.id != pos_id).order_by(Position.name).all()
        beats = db.query(Beat).filter(Beat.is_active == True).order_by(Beat.name).all()
        users = db.query(User).filter(User.is_active == True).order_by(User.full_name).all()
        return templates.TemplateResponse("positions/form.html", {
            "request": request, "current_user": current_user,
            "item": item, "managers": managers, "beats": beats, "users": users, "PositionLevel": PositionLevel,
            "error": err,
        })

    item.name = name
    item.code = code.upper()
    item.level = PositionLevel(level)
    item.reporting_to_id = int(reporting_to_id) if (reporting_to_id and reporting_to_id.strip() != "") else None
    
    item.beats.clear()
    if beat_ids:
        beat_objs = db.query(Beat).filter(Beat.id.in_(beat_ids)).all()
        item.beats.extend(beat_objs)

    item.users.clear()
    if attached_user_id and attached_user_id.strip() != "":
        user_obj = db.query(User).filter(User.id == int(attached_user_id)).first()
        if user_obj:
            item.users.append(user_obj)
        
    db.commit()
    set_flash_success(request, f"Position '{name}' updated.")
    return RedirectResponse("/positions", status_code=302)


@router.post("/{pos_id}/activate")
async def position_activate(
    pos_id: int, request: Request,
    current_user: User = Depends(require_web_roles(UserRole.admin)),
    db: Session = Depends(get_db),
):
    item = db.query(Position).filter(Position.id == pos_id).first()
    if item:
        item.is_active = True
        db.commit()
        set_flash_success(request, f"'{item.name}' activated.")
    return RedirectResponse("/positions", status_code=302)


@router.post("/{pos_id}/delete")
async def position_delete(
    pos_id: int, request: Request,
    current_user: User = Depends(require_web_roles(UserRole.admin)),
    db: Session = Depends(get_db),
):
    item = db.query(Position).filter(Position.id == pos_id).first()
    if item:
        if not item.is_vacant:
            set_flash_error(request, f"Cannot deactivate '{item.name}' because it has active assigned users.")
            return RedirectResponse("/positions", status_code=302)
        if any(rp.is_active for rp in item.direct_reports):
            set_flash_error(request, f"Cannot deactivate '{item.name}' because it has active direct reports.")
            return RedirectResponse("/positions", status_code=302)
        
        item.is_active = False
        db.commit()
        set_flash_success(request, f"'{item.name}' deactivated.")
    return RedirectResponse("/positions", status_code=302)


@router.get("/{pos_id}/attach-beats", response_class=HTMLResponse)
async def position_attach_beats_get(
    pos_id: int, request: Request,
    current_user: User = Depends(require_web_roles(UserRole.admin)),
    db: Session = Depends(get_db),
):
    item = db.query(Position).filter(Position.id == pos_id).first()
    if not item or not item.is_active:
        set_flash_error(request, "Active position not found.")
        return RedirectResponse("/positions", status_code=302)
    if item.level != PositionLevel.L1:
        set_flash_error(request, "Beats can only be attached to L1 positions.")
        return RedirectResponse("/positions", status_code=302)
        
    all_beats = db.query(Beat).filter(Beat.is_active == True).order_by(Beat.name).all()
    assigned_beat_ids = [b.id for b in item.beats]
    
    return templates.TemplateResponse("positions/attach_beats.html", {
        "request": request,
        "current_user": current_user,
        "item": item,
        "all_beats": all_beats,
        "assigned_beat_ids": assigned_beat_ids,
        **get_flash(request),
    })


@router.post("/{pos_id}/attach-beats")
async def position_attach_beats_post(
    pos_id: int, request: Request,
    current_user: User = Depends(require_web_roles(UserRole.admin)),
    db: Session = Depends(get_db),
    beat_ids: list[str] = Form(default=[]),
):
    item = db.query(Position).filter(Position.id == pos_id).first()
    if not item or not item.is_active:
        set_flash_error(request, "Active position not found.")
        return RedirectResponse("/positions", status_code=302)
    if item.level != PositionLevel.L1:
        set_flash_error(request, "Beats can only be attached to L1 positions.")
        return RedirectResponse("/positions", status_code=302)
        
    item.beats.clear()
    if beat_ids:
        beat_objs = db.query(Beat).filter(Beat.id.in_(beat_ids)).all()
        item.beats.extend(beat_objs)
        
    db.commit()
    set_flash_success(request, f"Beats mapping updated for position '{item.name}'.")
    return RedirectResponse("/positions", status_code=302)
